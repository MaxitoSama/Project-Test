#include "SDL/include/SDL.h"
#include <iostream>

#pragma comment( lib, "SDL/libx86/SDL2.lib")
#pragma comment( lib, "SDL/libx86/SDL2main.lib")

int main(int argc, char* args[])
{
	SDL_Init(SDL_INIT_EVERYTHING);

	SDL_Window* max;
	SDL_Renderer* maxito;

	SDL_CreateWindowAndRenderer(400, 400, SDL_WINDOW_RESIZABLE, &max, &maxito);//Create a window

	SDL_SetRenderDrawColor(maxito, 255, 0, 0, 255);//red
	SDL_RenderClear(maxito); // Clear the window and make it all red

	SDL_Rect rect = { 150,175,100,50 };   //Create a rectangle in the position 150,175 with the size 100x50
	SDL_SetRenderDrawColor(maxito, 0, 0, 255, 255);   //Color of the rectangle

	SDL_RenderDrawRect(maxito, &rect);// Render (draw) the edges of the rectangle
	SDL_RenderFillRect(maxito, &rect);//Painting all the rectangle
	SDL_RenderPresent(maxito);// Render the changes above(per sobre)

	for (;;)  //bucle infinit
	{

	}

	SDL_Quit();

	return 0;
}